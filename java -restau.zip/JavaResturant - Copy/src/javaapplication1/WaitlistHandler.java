package javaapplication1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextArea;

public class WaitlistHandler {
    private Queue<WaitlistEntry> waitlist = new LinkedList<>();
    private static final String DB_URL = "jdbc:sqlite:library.sqlite"; // Replace with your actual database URL
    private static final String DB_USER = "";
    private static final String DB_PASSWORD = "";

    public int addToWaitlist(String customerName) {
        int arrivalNumber = waitlist.size() + 1;
        WaitlistEntry entry = new WaitlistEntry(arrivalNumber, customerName);
        waitlist.offer(entry);
        saveToDatabase(entry);
        return arrivalNumber;
    }

    public void deleteFromWaitlist(int arrivalNumber) {
        waitlist.removeIf(entry -> entry.getArrivalNumber() == arrivalNumber);
        deleteFromDatabase(arrivalNumber);
    }

    public Queue<WaitlistEntry> getWaitlist() {
        return waitlist;
    }

    public void updateWaitlistComponents(JList<String> waitlistJList, JTextArea waitlistUserTextArea) {
        // Update the JList
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (WaitlistEntry entry : waitlist) {
            listModel.addElement(entry.toString());
        }
        waitlistJList.setModel(listModel);

        // Update the JTextArea
        StringBuilder waitlistText = new StringBuilder();
        for (WaitlistEntry entry : waitlist) {
            waitlistText.append(entry.toString()).append("\n");
        }
        waitlistUserTextArea.setText(waitlistText.toString());
    }

    // Inner class for encapsulation
    private static class WaitlistEntry {
        private final int arrivalNumber;
        private final String customerName;

        public WaitlistEntry(int arrivalNumber, String customerName) {
            this.arrivalNumber = arrivalNumber;
            this.customerName = customerName;
        }

        public int getArrivalNumber() {
            return arrivalNumber;
        }

        public String getCustomerName() {
            return customerName;
        }

        @Override
        public String toString() {
            return arrivalNumber + ". " + customerName;
        }
    }

    private void saveToDatabase(WaitlistEntry entry) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String insertSQL = "INSERT INTO waitlist (arrival_number, customer_name) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
                preparedStatement.setInt(1, entry.getArrivalNumber());
                preparedStatement.setString(2, entry.getCustomerName());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteFromDatabase(int arrivalNumber) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String deleteSQL = "DELETE FROM waitlist WHERE arrival_number = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
                preparedStatement.setInt(1, arrivalNumber);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
